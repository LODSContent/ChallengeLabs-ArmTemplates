Configuration ContosoWebsite
{
  param ($MachineName)

  Import-DscResource -ModuleName xWebAdministration

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
      DependsOn = @('[WindowsFeature]IIS')
    }

    # Install IIS Console
    WindowsFeature IISConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
        DependsOn ='[WindowsFeature]IIS'
    }

    xWebsite DefaultSite
    
    {
        Ensure = 'Present'
        Name = 'Default Web Site'        
        PhysicalPath = 'C:\inetpub\wwwroot'
        DependsOn = @('[WindowsFeature]IIS','[WindowsFeature]AspNet')
    }
        File wwwroot
   {
        Ensure = 'Present'
        Type = 'Directory'
        DestinationPath = "C:\inetpub\wwwroot"
    }

    File Indexfile
    {
        Ensure = 'Present'
        Type = 'file'
        DestinationPath = "C:\inetpub\wwwroot\index.html"
        Contents = "<html>
        <header><title>$MachineName</title></header>
        <body>
        Welcome to the web page on $MachineName
        </body>
        </html>"
    }
  }
} 