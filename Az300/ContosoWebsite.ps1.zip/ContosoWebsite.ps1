Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
      DependsOn = @('[WindowsFeature]IIS')
    }

    # Install IIS Console
    WindowsFeature IISConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
        DependsOn ='[WindowsFeature]IIS'
    }
    
    Script IndexHtmlFile
    {
        GetScript = { @{ Result = (Test-Path -Path 'C:\inetpub\wwwroot\index.html') } }
        SetScript = {
            $outFile = 'C:\inetpub\wwwroot\index.html'
            Invoke-WebRequest 'https://raw.githubusercontent.com/LODSContent/ChallengeLabs-ArmTemplates/master/Az300/Index.html' -OutFile $outFile
            Unblock-File -Path $outFile
        }
        TestScript = { Test-Path -Path 'C:\inetpub\wwwroot\index.html' }
        DependsOn = '[WindowsFeature]IIS'
    }
   
    Script ReplaceString
    {
        GetScript = { @{ Result = (Get-Content C:\inetpub\wwwroot\index.html | Where-Object { $_.Contains($using:MachineName) } ) } }
        SetScript = {
            ((Get-Content -path C:\inetpub\wwwroot\index.html -Raw) -replace 'WebServer',$using:MachineName) | Set-Content -Path C:\inetpub\wwwroot\index.html
        }
        TestScript = { Get-Content C:\inetpub\wwwroot\index.html | Where-Object { $_.Contains($using:MachineName) } }
        DependsOn = '[Script]IndexHtmlFile'
    }    
  }
} 